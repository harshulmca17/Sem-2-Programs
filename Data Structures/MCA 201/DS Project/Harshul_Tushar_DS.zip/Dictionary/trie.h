#ifndef TRIE_H
#define TRIE_H
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QFile>
#include<QtCore>
#include<QDataStream>
#include<QMessageBox>
#include<QTextStream>
#include<stack>
#include<iostream>
#include<cstring>
#include<bits/stdc++.h>
#include<fstream>

#define FILE_NAME "meaning.dat"

using namespace std;

#define ALPHABET_SIZE (128)

#define CHAR_TO_INDEX(c) ((int)c - (int)'a')


stack <string> s;
struct Meaning
{
    QString word;
    QString meaning;
}obj;


struct TrieNode
{
    /*
        objective: Create a structure for a Node for Trie Tree
        input parameters: none
        output value: none
        description: Tree class defines the node structure
        approach: strucutre defines data item is names element with datatype TrieNode
                and string termination with bool
     */
    struct TrieNode *children[ALPHABET_SIZE];

    bool isWordEnd;
};

struct TrieNode *getNode(void)
{
    /*
    objective: Create a dummy node for Trie Tree
    input parameters: none
    output value: none
    approach: using same approach as class constructor
    */
    struct TrieNode *pNode = new TrieNode;
    pNode->isWordEnd = false;

    for (int i = 0; i < ALPHABET_SIZE; i++)
        pNode->children[i] = NULL;

    return pNode;
}

void insert(struct TrieNode *root, const string key )
{
    /*
    objective: to insert a alphabet in its correct position and also determines the termination of string
    input parameters: root node ( TrieNode * ) and key for insertion ( const String )
    output value: none
    */
    struct TrieNode *temp = root;

    for (int level = 0; level < key.length(); level++)
    {
        int index = CHAR_TO_INDEX(key[level]);
        if (!temp->children[index])
            temp->children[index] = getNode();

        temp = temp->children[index];
    }

    temp->isWordEnd = true;
}
bool search(struct TrieNode *root, const string key)
{
    /*
    objective: to search a string in its correct position and also determines the termination of string
    input parameters: root node ( TrieNode * ) and key for insertion ( const String )
    output value: true or false ( bool )
    */

    int length = key.length();
    struct TrieNode *temp = root;
    for (int level = 0; level < length; level++)
    {
        int index = CHAR_TO_INDEX(key[level]);
        if (!temp->children[index])
        {
            return false;
        }

        temp = temp->children[index];
    }

    return (temp != NULL && temp->isWordEnd);
}

bool isLastNode(struct TrieNode* root)
{
    /*
    objective: to determine that a node is leaf node or not
    input parameters: root node ( TrieNode * )
    output value: true or false ( bool )
    */

    for (int i = 0; i < ALPHABET_SIZE; i++)
        if (root->children[i])
            return 0;
    return 1;
}


void suggestionsRec(struct TrieNode* root, string currPrefix)
{
    /*
    objective: to print every possible string match to its end node
    input parameters: root node ( TrieNode * ) and prefix ( const String )
    output value: none
    approach: recursive
    */

    if (root->isWordEnd)
    {
        s.push(currPrefix);

    }

    if (isLastNode(root))
        return;

    for (int i = 0; i < ALPHABET_SIZE; i++)
    {
        if (root->children[i])
        {
            currPrefix.push_back(97 + i);

            suggestionsRec(root->children[i], currPrefix);
        }
    }
}

int printAutoSuggestions(TrieNode* root, const string query)
{
    /*
    objective: to traverse to the last node of prefix
    input parameters: root node ( TrieNode * ) and query for insertion ( const String )
    output value: 0 in case no such prefix exist
    */

    struct TrieNode* temp = root;
    int level;
    int n = query.length();
    for (level = 0; level < n; level++)
    {
        int index = CHAR_TO_INDEX(query[level]);

        if (!temp->children[index])
            return 0;

        temp = temp->children[index];
    }

    bool isWord = (temp->isWordEnd == true);
    bool isLast = isLastNode(temp);

    if (isWord && isLast)
    {
        cout << query << endl;
        return -1;
    }

    if (!isLast)
    {
        string prefix = query;
        suggestionsRec(temp, prefix);
        return 1;
    }
}

#endif // TRIE_H
