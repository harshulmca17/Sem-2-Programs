#include "trie.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QFile>
#include<QtCore>
#include<QDataStream>
#include<QMessageBox>
#include<QTextStream>
#include<QKeyEvent>
#include<stack>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
QString meaning1;
TrieNode * head = getNode();
void MainWindow::on_pushButton_clicked()
{

    QString word,meaning;
    meaning1 = meaning;
    word = ui->lineEdit->text();
    meaning = ui->lineEdit_2->text();
    insert(head,word.toStdString());

    QFile myFile("meaning.txt");
    if(myFile.open(QIODevice::WriteOnly|QIODevice::Append|QIODevice::Text))
      {
        QTextStream out(&myFile);
        out<<word<<":"<<meaning<<"\n";

            //myFile.write(reinterpret_cast<char*>(&obj), sizeof(obj));
    }
    else
        QMessageBox::warning(this,"title","Error in opening file");
    myFile.flush();
    myFile.close();
    QMessageBox::information(this,"title","Insertion Done");
}

void MainWindow::on_pushButton_2_clicked()
{
    QString word,meaning;
    meaning = meaning1;
    word = ui->lineEdit_3->text();
    QFile myFile("meaning.txt");

    if(search(head,word.toStdString()))

    {

        if(myFile.open(QIODevice::ReadOnly|QIODevice::Text))
          {
            QTextStream in(&myFile);
            QString line;
            QStringList temp;
            QString check = word+" "+meaning;
            do{
                cout<<"1";
                line = in.readLine();
                temp = line.split(":");

                cout<<temp[0].toStdString()<<" \n"<<word.toStdString();
                if(temp[0] == word)
                 {cout<<"@";
                    ui->lineEdit_4->setText(QString(temp[1]));
                }
            }while(!line.isNull());

           }

        else
        {    QMessageBox::warning(this,"title","Error in opening file");
        }
        QMessageBox::information(this,"title","Word Found");
    }
    else{
        QMessageBox::warning(this,"title","Not Found");

        ui->lineEdit_4->setText("Not Found");
    }



}
/*void MainWindow::keyPressEvent(QKeyEvent *e){
    QString text = ui->label_3->text();
    text += char(e->key());
    printAutoSuggestions(head,text.toStdString());
    stack <string> s1 = giveSuggestion();
    cout<<s1.top();
    //ui->textEdit->setText(QString(s1.top()));
}*/

