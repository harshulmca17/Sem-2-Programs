#ifndef OVERLOADES_H
#define OVERLOADES_H
#include "trie.h"
#include<QtCore>

QDataStream &operator <<(QDataStream &out, const Meaning &obj);
QDataStream &operator >>(QDataStream &in, Meaning &obj);


QDataStream &operator <<(QDataStream &out, const Meaning &obj){
    out<<obj.word<<obj.word;
    return out;
}

QDataStream &operator >>(QDataStream &in, Meaning &obj){
    in>>obj.word>>obj.meaning;
    return in;
}

#endif // OVERLOADES_H
